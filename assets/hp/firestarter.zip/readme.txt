 **	Type:   Shoot'em up
  **	Title:  FireStarter
   **	Coder:  SunHP
    **	Date:   6/07/97

FIRESTARTER is my first Space game, and I hope
you will enjoy it, then distribute it.

You play FIRESTARTER with:

[4] left
[6] right
[enter] quit

Alien War begin !!!

SunHP
