**** SUBJECT: MEGANOID v2.1 *
*** TYPE:     Arcade       **
** AUTHOR:    SunHP       ***
* DATE:       10/07/97   ****
Copyright (c) 1997, by SunHP.


This game is POSTWARE.

So if you like it,
send me a POSTCARD 
from your country.

Thanks!

	STANDARD keys are:

[A] sound ON/OFF
[B] Play
[C] 1P/2P
[D] Keys
[E] About
[F] quit

	A/ 1 Player MODE:

[4]	 LEFT
[6]	 RIGHT

	B/ 2 players MODE:

[GREEN] LEFT
[1] 	RIGHT
[9] 	LEFT
[/] 	RIGHT

	C/ MISC other:

[DROP] 	QUIT
[+] 	contrast +
[-] 	contrast -


SunHP