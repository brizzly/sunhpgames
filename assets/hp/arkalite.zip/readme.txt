		*********************************************************
		*							*
		*	     		ARKALITE v1.2			*
		* 		by Julien Meyer (SunHP)	XL Coding	*
		*							*
		*********************************************************

				Copyright (c) 1997 by SunHP


This game is an Arcade Freeware program ML written. ARKALITE runs only on HP48G(X)
in port 0 or 1. This game is  the smallest and nicest Arkanoid game.

ARKALITE is a library object, put it in the stack, push 0 (or 1 to store ARKALITE
in Ram Card), then STO. Now turn OFF then ON your HP48G(X) The game is installed.
Goto Library to play ARKALITE (right shift  + [2]).


How to play ARKALITE game:
==========================

				[G] 	left
				[L] 	right
				[ENTER] quit

When you broke all bricks in the screen, the level is cleared. Then, you go to
another Randomized new level. When you lost, there is your ARKALITE score in the
stack. I hope you will find this game amazing, then distribute it. Any suggestions,
remarks, comments are welcome, just send-me an e-mail. 

					Enjoy it !

				Julien MEYER - SunHP
