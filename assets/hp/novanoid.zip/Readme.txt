	*****************************************
	*	      NOVANOID v1.0		*
	* 		by SunHP		*
	*****************************************

		Copyright (c) 1997 by SunHP


	This game is an Arcade Freeware game.
It looks like DIAMONDS, but I've reprogrammed a
two players new game. Thanks to Douglas Cannon for
his help and files!

	NOVANOID is a library object who runs only
on HP48G(X) in port 0 or 1.

	This is the version 1.0, and I think there
are many bugs in it.. so if you find one, please 
send me an e-mail, I'll try to fix it !


		How to play NOVANOID

First, when NOVANOID appears, hit [ENTER] to show menu.

		[A] START BATTLE !!
		[B] RANDOM BATTLE
		[C] ABOUT KEYS
		[D] QUIT..

	You can play NOVANOID only in 2 players mode:

		[M_O] 	left_right PLAYER ONE
		[2_-] 	left_right PLAYER TWO
		[DROP] 	during the game, return
			to the presentation.


			Enjoy it !

		Julien MEYER - SunHP
